export class Feedback {
    id?: Number;
    title!: String;
    description!: String;
    createdAt!: Date;
    graduateId?: Number;
}