export class User {
    id?: Number;
    name!: String;
    emailId!: String;
    designation!: String;
    authCode!: String;
    photoUrl !: String;
}