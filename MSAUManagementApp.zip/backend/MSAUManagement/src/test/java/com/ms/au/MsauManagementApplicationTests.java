package com.ms.au;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsauManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
