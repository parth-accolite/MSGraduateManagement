package com.ms.au;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsauManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsauManagementApplication.class, args);
	}

}
